#include "Common.h"
#include <iostream>
#include <vector>
#include <cstdlib>
#include <string>

int main() {
    std::cout << "RECEIVER\nFile name: 1 - enter, 2 - environment variable Sevruk\n> ";
    int choice = 0;
    if (!(std::cin >> choice) || (choice != 1 && choice != 2)) return 1;

    std::string filename;
    if (choice == 1) {
        std::cout << "File name: ";
        std::getline(std::cin >> std::ws, filename);
    } else {
        char* value = nullptr;
        size_t length = 0;
        int error = _dupenv_s(&value, &length, "Sevruk");
        if (error != 0 || value == nullptr || value[0] == '\0') {
            std::cout << "Environment variable Sevruk is missing.\n";
            free(value);
            return 1;
        }
        filename = value;
        free(value);
        std::cout << "File name from Sevruk: " << filename << '\n';
    }
    if (filename.empty()) return 1;

    int capacity = 0;
    int senderCount = 0;
    std::cout << "Number of records: ";
    if (!(std::cin >> capacity) || capacity < 1) return 1;
    std::cout << "Number of Sender processes: ";
    if (!(std::cin >> senderCount) || senderCount < 1) return 1;

    HANDLE file = CreateFileA(filename.c_str(), GENERIC_READ | GENERIC_WRITE,
                              FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                              CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        std::cout << "Cannot create binary file. Error: " << GetLastError() << '\n';
        return 1;
    }

    Header header{static_cast<DWORD>(capacity), 0, 0};
    LARGE_INTEGER fileSize{};
    fileSize.QuadPart = sizeof(Header) + static_cast<LONGLONG>(capacity) * sizeof(Message);
    if (!writeAt(file, 0, &header, sizeof(header)) ||
        !SetFilePointerEx(file, fileSize, nullptr, FILE_BEGIN) || !SetEndOfFile(file)) {
        std::cout << "Cannot initialize binary file.\n";
        CloseHandle(file);
        return 1;
    }

    std::string id = std::to_string(GetCurrentProcessId());
    HANDLE mutex = CreateMutexA(nullptr, FALSE, ipcName(id, "mutex").c_str());
    HANDLE freeSlots = CreateSemaphoreA(nullptr, capacity, capacity, ipcName(id, "free").c_str());
    HANDLE usedSlots = CreateSemaphoreA(nullptr, 0, capacity, ipcName(id, "used").c_str());
    HANDLE ready = CreateSemaphoreA(nullptr, 0, senderCount, ipcName(id, "ready").c_str());
    HANDLE stop = CreateEventA(nullptr, TRUE, FALSE, ipcName(id, "stop").c_str());

    if (!mutex || !freeSlots || !usedSlots || !ready || !stop) {
        std::cout << "Cannot create synchronization objects.\n";
        if (stop) CloseHandle(stop);
        if (ready) CloseHandle(ready);
        if (usedSlots) CloseHandle(usedSlots);
        if (freeSlots) CloseHandle(freeSlots);
        if (mutex) CloseHandle(mutex);
        CloseHandle(file);
        return 1;
    }

    char self[MAX_PATH]{};
    DWORD pathLength = GetModuleFileNameA(nullptr, self, MAX_PATH);
    if (pathLength == 0 || pathLength >= MAX_PATH) {
        std::cout << "Cannot find the executable folder.\n";
        SetEvent(stop);
        CloseHandle(stop); CloseHandle(ready); CloseHandle(usedSlots);
        CloseHandle(freeSlots); CloseHandle(mutex); CloseHandle(file);
        return 1;
    }
    std::string folder = self;
    size_t slash = folder.find_last_of("\\/");
    std::string senderExe = folder.substr(0, slash + 1) + "Sender.exe";

    int launched = 0;
    while (launched < senderCount) {
        std::string command = "\"" + senderExe + "\" \"" + filename + "\" " + id;
        std::vector<char> commandLine(command.begin(), command.end());
        commandLine.push_back('\0');
        STARTUPINFOA start{};
        start.cb = sizeof(start);
        PROCESS_INFORMATION process{};
        if (!CreateProcessA(senderExe.c_str(), commandLine.data(), nullptr, nullptr,
                            FALSE, CREATE_NEW_CONSOLE, nullptr, nullptr, &start, &process)) {
            std::cout << "Cannot start Sender.exe (place it next to Receiver.exe).\n";
            SetEvent(stop);
            CloseHandle(stop); CloseHandle(ready); CloseHandle(usedSlots);
            CloseHandle(freeSlots); CloseHandle(mutex); CloseHandle(file);
            return 1;
        }
        CloseHandle(process.hThread);
        CloseHandle(process.hProcess);
        ++launched;
    }

    std::cout << "Waiting for " << senderCount << " Sender processes...\n";
    int connected = 0;
    while (connected < senderCount) {
        if (WaitForSingleObject(ready, INFINITE) != WAIT_OBJECT_0) break;
        ++connected;
        std::cout << "Sender ready: " << connected << '/' << senderCount << '\n';
    }

    if (connected == senderCount) {
        int action = 0;
        while (true) {
            std::cout << "\n1 - read message, 2 - exit\n> ";
            if (!(std::cin >> action) || action == 2) break;
            if (action != 1) continue;

            std::cout << "Waiting for a message if the queue is empty...\n";
            if (WaitForSingleObject(usedSlots, INFINITE) != WAIT_OBJECT_0) break;
            if (!lockMutex(mutex)) break;

            Header state{};
            Message message{};
            bool ok = readAt(file, 0, &state, sizeof(state));
            if (ok) ok = readAt(file, messagePosition(state.head), &message, sizeof(message));
            if (ok) {
                state.head = (state.head + 1) % state.capacity;
                ok = writeAt(file, 0, &state, sizeof(state));
            }
            ReleaseMutex(mutex);
            ReleaseSemaphore(ok ? freeSlots : usedSlots, 1, nullptr);
            if (!ok) {
                std::cout << "Error reading binary file.\n";
                break;
            }
            message.text[19] = '\0';
            std::cout << "Received: " << message.text << '\n';
        }
    }

    SetEvent(stop); // Wake up Sender processes blocked on a full queue.
    CloseHandle(stop);
    CloseHandle(ready);
    CloseHandle(usedSlots);
    CloseHandle(freeSlots);
    CloseHandle(mutex);
    CloseHandle(file);
    return connected == senderCount ? 0 : 1;
}
