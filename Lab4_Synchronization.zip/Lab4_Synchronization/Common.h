#pragma once

#include <windows.h>
#include <string>

// Binary file: [Header][Message 0][Message 1] ... [Message N-1]
struct Header {
    DWORD capacity;
    DWORD head;
    DWORD tail;
};

struct Message {
    char text[20]; // Up to 19 characters + terminating '\0'
};

static_assert(sizeof(Header) == 12, "Unexpected file header size");
static_assert(sizeof(Message) == 20, "Unexpected message size");

inline LONGLONG messagePosition(DWORD index) {
    return sizeof(Header) + static_cast<LONGLONG>(index) * sizeof(Message);
}

inline bool readAt(HANDLE file, LONGLONG position, void* data, DWORD size) {
    LARGE_INTEGER offset{};
    offset.QuadPart = position;
    DWORD bytes = 0;
    return SetFilePointerEx(file, offset, nullptr, FILE_BEGIN) &&
           ReadFile(file, data, size, &bytes, nullptr) && bytes == size;
}

inline bool writeAt(HANDLE file, LONGLONG position, const void* data, DWORD size) {
    LARGE_INTEGER offset{};
    offset.QuadPart = position;
    DWORD bytes = 0;
    return SetFilePointerEx(file, offset, nullptr, FILE_BEGIN) &&
           WriteFile(file, data, size, &bytes, nullptr) && bytes == size;
}

inline std::string ipcName(const std::string& id, const char* part) {
    return "Local\\Lab4_" + id + "_" + part;
}

inline bool lockMutex(HANDLE mutex) {
    DWORD result = WaitForSingleObject(mutex, INFINITE);
    return result == WAIT_OBJECT_0 || result == WAIT_ABANDONED;
}
