#include "Common.h"
#include <iostream>
#include <limits>
#include <cstring>

int main(int argc, char* argv[]) {
    if (argc != 3) {
        std::cout << "Start this process through Receiver.exe.\n";
        return 1;
    }

    // argv[1] = binary file name, argv[2] = Receiver process ID.
    std::string filename = argv[1];
    std::string id = argv[2];
    HANDLE file = CreateFileA(filename.c_str(), GENERIC_READ | GENERIC_WRITE,
                              FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr,
                              OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    HANDLE mutex = OpenMutexA(SYNCHRONIZE | MUTEX_MODIFY_STATE, FALSE, ipcName(id, "mutex").c_str());
    HANDLE freeSlots = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, ipcName(id, "free").c_str());
    HANDLE usedSlots = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, ipcName(id, "used").c_str());
    HANDLE ready = OpenSemaphoreA(SEMAPHORE_ALL_ACCESS, FALSE, ipcName(id, "ready").c_str());
    HANDLE stop = OpenEventA(SYNCHRONIZE, FALSE, ipcName(id, "stop").c_str());

    if (file == INVALID_HANDLE_VALUE || !mutex || !freeSlots || !usedSlots || !ready || !stop) {
        std::cout << "Cannot open the shared file or synchronization objects.\n";
        if (file != INVALID_HANDLE_VALUE) CloseHandle(file);
        if (mutex) CloseHandle(mutex);
        if (freeSlots) CloseHandle(freeSlots);
        if (usedSlots) CloseHandle(usedSlots);
        if (ready) CloseHandle(ready);
        if (stop) CloseHandle(stop);
        return 1;
    }

    ReleaseSemaphore(ready, 1, nullptr);
    CloseHandle(ready);
    std::cout << "SENDER (PID " << GetCurrentProcessId() << ") ready.\n";

    int action = 0;
    while (WaitForSingleObject(stop, 0) != WAIT_OBJECT_0) {
        std::cout << "\n1 - send message, 2 - exit\n> ";
        if (!(std::cin >> action) || action == 2) break;
        if (action != 1) continue;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "Message (1-19 characters): ";
        std::string text;
        std::getline(std::cin, text);
        if (text.empty() || text.size() >= 20) {
            std::cout << "Invalid message length.\n";
            continue;
        }

        std::cout << "Waiting for a free record if the queue is full...\n";
        HANDLE waitObjects[] = {stop, freeSlots};
        DWORD wait = WaitForMultipleObjects(2, waitObjects, FALSE, INFINITE);
        if (wait == WAIT_OBJECT_0) break;
        if (wait != WAIT_OBJECT_0 + 1) break;
        if (WaitForSingleObject(stop, 0) == WAIT_OBJECT_0) {
            ReleaseSemaphore(freeSlots, 1, nullptr);
            break;
        }
        if (!lockMutex(mutex)) {
            ReleaseSemaphore(freeSlots, 1, nullptr);
            break;
        }

        Header state{};
        Message message{};
        std::memcpy(message.text, text.c_str(), text.size());
        bool ok = readAt(file, 0, &state, sizeof(state));
        if (ok) ok = writeAt(file, messagePosition(state.tail), &message, sizeof(message));
        if (ok) {
            state.tail = (state.tail + 1) % state.capacity;
            ok = writeAt(file, 0, &state, sizeof(state));
        }
        ReleaseMutex(mutex);
        ReleaseSemaphore(ok ? usedSlots : freeSlots, 1, nullptr);
        if (!ok) {
            std::cout << "Error writing binary file.\n";
            break;
        }
        std::cout << "Sent: " << text << '\n';
    }

    std::cout << "Sender finished.\n";
    CloseHandle(stop);
    CloseHandle(usedSlots);
    CloseHandle(freeSlots);
    CloseHandle(mutex);
    CloseHandle(file);
    return 0;
}
